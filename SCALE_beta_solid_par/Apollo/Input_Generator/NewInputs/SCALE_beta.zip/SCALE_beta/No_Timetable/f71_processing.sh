cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_102/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_102.f71 > MSBR_beta_102.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_104/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_104.f71 > MSBR_beta_104.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_106/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_106.f71 > MSBR_beta_106.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_108/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_108.f71 > MSBR_beta_108.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_110/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_110.f71 > MSBR_beta_110.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_112/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_112.f71 > MSBR_beta_112.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_114/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_114.f71 > MSBR_beta_114.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_116/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_116.f71 > MSBR_beta_116.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_132/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_132.f71 > MSBR_beta_132.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_164/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_164.f71 > MSBR_beta_164.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_228/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_228.f71 > MSBR_beta_228.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_356/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_356.f71 > MSBR_beta_356.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_612/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_612.f71 > MSBR_beta_612.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSBR/MSBR_beta_1124/
f71tocsv.exe -symbols=1 -units=gram MSBR_beta_1124.f71 > MSBR_beta_1124.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_102/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_102.f71 > MSRE_beta_102.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_104/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_104.f71 > MSRE_beta_104.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_106/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_106.f71 > MSRE_beta_106.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_108/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_108.f71 > MSRE_beta_108.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_110/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_110.f71 > MSRE_beta_110.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_112/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_112.f71 > MSRE_beta_112.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_114/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_114.f71 > MSRE_beta_114.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_116/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_116.f71 > MSRE_beta_116.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_132/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_132.f71 > MSRE_beta_132.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_164/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_164.f71 > MSRE_beta_164.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_228/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_228.f71 > MSRE_beta_228.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_356/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_356.f71 > MSRE_beta_356.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_612/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_612.f71 > MSRE_beta_612.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSRE/MSRE_beta_1124/
f71tocsv.exe -symbols=1 -units=gram MSRE_beta_1124.f71 > MSRE_beta_1124.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_102/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_102.f71 > MSDR_beta_102.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_104/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_104.f71 > MSDR_beta_104.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_106/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_106.f71 > MSDR_beta_106.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_108/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_108.f71 > MSDR_beta_108.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_110/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_110.f71 > MSDR_beta_110.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_112/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_112.f71 > MSDR_beta_112.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_114/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_114.f71 > MSDR_beta_114.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_116/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_116.f71 > MSDR_beta_116.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_132/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_132.f71 > MSDR_beta_132.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_164/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_164.f71 > MSDR_beta_164.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_228/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_228.f71 > MSDR_beta_228.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_356/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_356.f71 > MSDR_beta_356.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_612/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_612.f71 > MSDR_beta_612.csv

cd /mnt/c/Users/vicen/Desktop/SCALE_beta_solid_par/Apollo/MSDR/MSDR_beta_1124/
f71tocsv.exe -symbols=1 -units=gram MSDR_beta_1124.f71 > MSDR_beta_1124.csv

